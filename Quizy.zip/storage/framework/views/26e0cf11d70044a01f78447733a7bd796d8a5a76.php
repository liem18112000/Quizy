<?php $__env->startSection('content'); ?>
    <h1 style='padding-left: 40px;'>Course Management</h1>

    <hr/>

    <table id="example" class="table table-hover table-striped table-bordered" style="width:100%">
        <thead class='text-center'>
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Creator</th>
                <th>Exams</th>
                <th>Complete</th>
                <th>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <?php if($courses): ?>
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='text-center'>
                <td style='padding-top: 15px;'><?php echo e($course->id); ?></td>
                <td style='padding: 0; width: 60px;'>
                    <?php if($course->image == 'untitled'): ?>
                        <img
                            src="https://wallpaperplay.com/walls/full/1/3/2/296805.jpg" alt=""
                            class='img-responsive img-rounded'
                            style='height: 100px; width: 100px; object-fit: cover'>
                    <?php else: ?>
                        <img
                            src="<?php echo e($course->image); ?>" alt=""
                            class='img-responsive img-rounded'
                            style='height: 100px; width: 100px; object-fit: cover'>
                    <?php endif; ?>
                </td>
                <td style='padding-top: 15px;'><?php echo e($course->name); ?></td>
                <td style='padding-top: 15px;'><a href="#"><?php echo e(Auth::user()->name); ?></a></td>
                <td>
                    <a name="" id="" class="btn btn-primary" href="<?php echo e(route('lecturer.course.exam', $course)); ?>" role="button">
                        Exam Count : <?php echo e($course->exams->count()); ?>

                    </a>
                </td>
                <td><b></b></td>
                <td class='text-center' style='padding-top: 10px;'>
                    <a name="" id="" class="mx-1 btn btn-danger" href="#" role="button">Disable</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
        <tfoot class='text-center'>
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Creator</th>
                <th>Exams</th>
                <th>Complete</th>
                <th>&nbsp;</th>
            </tr>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lecturer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quizy\resources\views/lecturer/course.blade.php ENDPATH**/ ?>