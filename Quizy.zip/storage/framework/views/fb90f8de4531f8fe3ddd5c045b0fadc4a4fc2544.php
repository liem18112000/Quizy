

<?php $__env->startSection('styles'); ?>
    <style>
        .float-panel{
            position: fixed;
            width: 20%;
            top: 2vh;
            left: 5%;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="container-fluid" style='margin-top:2vh; margin-bottom:5vh'>
        <div class="row">
            <div class="col-lg-3">
                <div class='float-panel'>
                    <div class="row">
                        <div class='col-lg-12'>
                            <div class="card mb-2">
                                <div class="card-body">
                                    <h4 class="card-title text-center">Thoi gian còn lại</h4>

                                    <!-- Display the countdown timer in an element -->
                                    <h2 id="demo" class='text-center'></h2>

                                    <script>
                                        // Set the date we're counting down to
                                        var countDownDate = new Date("Oct 23, 2020 16:10:00").getTime();

                                        // Update the count down every 1 second
                                        var x = setInterval(function() {

                                        // Get today's date and time
                                        var now = new Date().getTime();

                                        // Find the distance between now and the count down date
                                        var distance = countDownDate - now;

                                        // Time calculations for days, hours, minutes and seconds
                                        var minutes = Math.floor(distance / (1000 * 60));
                                        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                                        // Display the result in the element with id="demo"
                                        document.getElementById("demo").innerHTML = minutes + " : " + seconds;

                                        // If the count down is finished, write some text
                                        if (distance < 0) {
                                            clearInterval(x);
                                            document.getElementById("demo").innerHTML = "EXPIRED";
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Hết thời gian',
                                                text: 'Hoàn thành bài làm!'
                                            });
                                            window.location.href = "<?php echo e(route('exam.index', $course)); ?>";
                                        }
                                        }, 1000);
                                    </script>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">

                                    <h4 class="card-title text-center">Câu hỏi</h4>

                                    <?php for($j = 0 ; $j < $questions->count() / 5 ; $j++): ?>
                                    <div class='mt-2' style='display:flex; justify-content: space-evenly;'>
                                        <?php for($k = 0; $k < 5; $k++): ?>
                                            <a name="" id="" class="btn btn-dark" style='width: 48px' href="#" role="button">
                                                <?php echo e($j * 5 + $k + 1); ?>

                                            </a>
                                        <?php endfor; ?>
                                    </div>
                                    <?php endfor; ?>

                                    <button type="submit" class="btn btn-primary mt-4 btn-block">Nộp Bài</button>

                                    <a class="btn btn-secondary btn-block" href="<?php echo e(route('exam.index', [$course])); ?>" role="button">Back</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-9">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card text-center" >
                            <div class="card-body">
                                <h1 class="card-title">Đề thi : <?php echo e($course->name); ?></h1>
                                <h5 class="card-text">Tên thí sinh: <?php echo e(Auth::user()->name); ?></h5>
                            </div>
                        </div>
                    </div>
                </div>


                <?php
                    $cau = 1;
                ?>

                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row mt-2"> <!-- Cau hoi -->
                    <div class="col-lg-12">
                        <div class="card" >
                            <div class="card-body">
                                <div style='display:flex; justify-content: space-between;'>
                                    <h4 class="card-title">Câu hỏi <?php echo e($cau); ?></h4>
                                    <div class="form-check">
                                      <label class="form-check-label">
                                        <input type="checkbox" class="form-check-input" name="" id="" value="checkedValue">
                                        Đánh dấu
                                      </label>
                                    </div>
                                </div>
                                <p class="card-text"><?php echo e($question->description); ?>?</p>


                                <?php
                                    $i = 1;
                                ?>

                                <?php $__currentLoopData = $question->choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <!-- Group of default radios - option 1 -->
                                <div class="custom-control custom-radio">
                                    <input type="radio" class="custom-control-input" id="defaultGroupExample<?php echo e($i); ?>" name="groupOfDefaultRadios">
                                    <label class="custom-control-label" for="defaultGroupExample<?php echo e($i); ?>"><?php echo e($choice->description); ?></label>
                                </div>

                                <?php
                                    $i++;
                                ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php
                                    $cau++;
                                ?>

                                

                            </div>
                        </div>
                    </div>
                </div><!-- Cau hoi -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appNoNavNoFoot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quizy\resources\views\exam\show.blade.php ENDPATH**/ ?>