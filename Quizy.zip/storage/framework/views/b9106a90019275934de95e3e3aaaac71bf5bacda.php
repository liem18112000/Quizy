<?php $__env->startSection('content'); ?>
    <h1 style='padding-left: 40px;'>User Management</h1>
    <table id="example" class="table table-hover table-striped table-bordered" style="width:100%">
        <thead>
            <tr class='text-center'>
                <th>UID</th>
                <th>Avatar</th>
                <th>Name</th>
                <th>Email</th>
                <th>Provider</th>
                <th>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='text-center'>
                <td><?php echo e($user->id); ?></td>
                <td style='padding: 0;'><img src='<?php if($user->profile): ?><?php echo e($user->profile->profile_image); ?><?php endif; ?>' class='img-responsive img-rounded' style='height: 150px; width: 150px; object-fit: cover'></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->provider); ?></td>
                <td class='text-center' style='padding-top: 10px; width: 170px'><a class="btn btn-info" href="<?php if($user->profile): ?><?php echo e(route('profile.show', $user->profile)); ?><?php endif; ?>" role="button">Profile</a>  <a name="" id="" class="mx-1 btn btn-danger" href="#" role="button">Diables</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class='text-center'>
            <tr>
                <th>UID</th>
                <th>Avatar</th>
                <th>Name</th>
                <th>Email</th>
                <th>Provider</th>
                <th>&nbsp;</th>
            </tr>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quizy\resources\views/admin/table/user.blade.php ENDPATH**/ ?>