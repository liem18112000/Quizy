<?php $__env->startSection('content'); ?>
    <h1 style='padding-left: 40px;'>Course : <?php echo e($course->name); ?></h1>

    <h2 style='padding-left: 40px;'>Exam Management</h2>

    <hr/>

    <table id="example" class="table table-hover table-striped table-bordered" style="width:100%">
        <thead class='text-center'>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Exam Type</th>
                <th>Duration</th>
                <th>Complete</th>
                <th>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='text-center'>
                <td><?php echo e($exam->id); ?></td>
                <td>
                    <?php echo e($exam->title); ?>

                </td>
                <td><?php echo e($exam->examType->name); ?></td>
                <td><?php echo e($exam->duration_min); ?></td>
                <td>
                    <?php if(Auth::user()->roles->where('role_type_id', '1')->first()->enrollCourse->where('course_id', $course->id)->first()->exams->where('exam_id', $exam->id)->count() == 0): ?>
                    <a name="" id="" class="btn btn-outline-warning" role="button">
                        Not Available
                    </a>
                    <?php else: ?>
                    <a name="" id="" class="btn btn-outline-success" role="button">
                        Exam Complete
                    </a>
                    <?php endif; ?>
                </td>
                <td class='text-center' style='padding-top: 10px;'>
                    <a name="" id="" class="btn btn-primary btn-block" href="<?php echo e(route('exam.show', [$exam->course, $exam])); ?>" role="button">Take exam</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class='text-center'>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Exam Type</th>
                <th>Duration</th>
                <th>Complete</th>
                <th>&nbsp;</th>
            </tr>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quizy\resources\views/student/exam.blade.php ENDPATH**/ ?>