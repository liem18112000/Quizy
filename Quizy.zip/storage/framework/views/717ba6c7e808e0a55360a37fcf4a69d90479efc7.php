<?php $__env->startSection('content'); ?>
    <h1 style='padding-left: 40px;'>Course : <?php echo e($course->name); ?></h1>

    <h2 style='padding-left: 40px;'>Exam : <?php echo e($exam->title); ?></h2>

    <h3 style='padding-left: 40px;'> Question Management</h3>

    <hr/>
    <!-- Button trigger modal -->
    <div style='padding-left: 40px;'>
        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#modelId">
            <i class="fa fa-plus" aria-hidden="true"></i>
            Add Question
        </button>
        <a name="" id="" class="btn btn-secondary" href="<?php echo e(route('lecturer.course.exam', [$course])); ?>" role="button">Back</a>
    </div>

    <!-- Modal -->
    <form method="POST" action="<?php echo e(route('lecturer.course.exam.question.store', [$course, $exam])); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Question Create</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                       <div class="form-group">
                            <label for="description">Question</label>
                            <input type="text" name="description" id="description" class="form-control" placeholder="Enter your question ..." aria-describedby="helpId">
                        </div>

                        <?php if($exam->examType->id == '1'): ?>
                        <hr/>
                        <?php for($i = 0; $i < 4; $i++): ?>
                            <div class="form-group">
                                <label for="choice<?php echo e($i); ?>">Choice <?php echo e($i + 1); ?> : </label>
                                <input type="text" name="choice<?php echo e($i); ?>" id="choice<?php echo e($i); ?>" class="form-control" placeholder="" aria-describedby="helpId">
                            </div>
                        <?php endfor; ?>

                        <div class="form-group">
                            <label for="">Answer : </label>
                            <select class="form-control" name="answer" id="answer">
                                <option value='0'>Choice 1</option>
                                <option value='1'>Choice 2</option>
                                <option value='2'>Choice 3</option>
                                <option value='3'>Choice 4</option>
                            </select>
                        </div>
                        <?php elseif($exam->examType->id == '2'): ?>
                        <div class="form-group">
                            <label for="time">Marks</label>
                            <input type="number" name="mark" id="duration" class="form-control" value='1' min='1' max='10' step='0.5' aria-describedby="helpId">
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <div class="container-fluid">
                            <div class='row'>
                                <div class='col-6'>
                                    <button type="button" class="btn btn-danger btn-block" data-dismiss="modal">Close</button>
                                </div>
                                <div class='col-6'>
                                    <button type="submit" class="btn btn-success btn-block">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <hr/>

    <table id="example" class="table table-hover table-striped table-bordered" style="width:100%">
        <thead class='text-center'>
            <tr>
                <th>ID</th>
                <th>Content</th>
                <?php if($exam->examType->id == '1'): ?>
                <th>Choices</th>
                <?php elseif($exam->examType->id == '2'): ?>
                <th>Marks</th>
                <?php endif; ?>
                <th>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='text-center'>
                <td><?php echo e($question->id); ?></td>
                <td>
                    <?php echo e($question->description); ?>

                </td>
                <?php if($exam->examType->id == '1'): ?>
                <td style='min-width: 30vw; padding: 0'>
                    <table class="table" style='margin: 0'>
                        <tbody>
                            <?php $__currentLoopData = $question->choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($choice->id); ?></td>
                                <?php if($choice->id == $question->answer_choice_id): ?>
                                    <td style='color:green'><b><?php echo e($choice->description); ?></b></td>
                                <?php else: ?>
                                    <td style='color:red'><b><?php echo e($choice->description); ?></b></td>
                                <?php endif; ?>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </td>
                <?php elseif($exam->examType->id == '2'): ?>
                    <td><?php echo e($question->answer_choice_id); ?></td>
                <?php endif; ?>
                <td class='text-center' style='padding-top: 10px;'>
                    <a name="" id="" class="mx-1 btn btn-danger" href="#" role="button">Disable</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class='text-center'>
            <tr>
                <th>ID</th>
                <th>Content</th>
                 <?php if($exam->examType->id == '1'): ?>
                <th>Choices</th>
                <?php elseif($exam->examType->id == '2'): ?>
                <th>Marks</th>
                <?php endif; ?>
                <th>&nbsp;</th>
            </tr>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lecturer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quizy\resources\views/lecturer/question.blade.php ENDPATH**/ ?>