<?php $__env->startSection('content'); ?>

<div class="text-center">
<h1>Course List</h1>
</div>


<div class="row">
<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-4 mb-4">
  <div class="card h-100">
    <a href="#"><img class="card-img-top" src="http://placehold.it/700x400" alt=""></a>
    <div class="card-body">
      <h4 class="card-title">
        <a href="<?php echo e(route('exam.index', $course)); ?>"><?php echo e($course->name); ?></a>
      </h4>
      <p class="card-text">UID: <?php echo e($course->id); ?></p>
      <p class="card-text">Date Created: <?php echo e($course->cresated_date); ?></p>
      <p class="card-text">Lecture:</p>
    </div>
    <div class="card-footer">
    <div class="text-center">
      <button class="btn btn-info">Enroll</button>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>
<!-- /.row -->



</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.lecturer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quizy\resources\views/lecturer/table/course.blade.php ENDPATH**/ ?>