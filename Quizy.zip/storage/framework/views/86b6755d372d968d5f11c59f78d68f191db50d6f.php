<?php $__env->startSection('content'); ?>
    <h1 style='padding-left: 40px;'>Request Management</h1>

    <hr/>

    <table id="example" class="table table-hover table-striped table-bordered" style="width:100%">
        <thead class='text-center'>
            <tr>
                <th>ID</th>
                <th>Type</th>
                <th>User</th>
                <th>Description</th>
                <th>Data</th>
                <th>Created at</th>
                <th>Status</th>
                <th>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='text-center'>
                <td><?php echo e($request->id); ?></td>
                <td>
                    <?php echo e($request->requestType->name); ?>

                </td>
                <td><?php echo e($request->user->name); ?></td>
                <td><?php echo e($request->description); ?></td>
                <td><?php echo e($request->data); ?></td>
                <td>
                    <?php echo e($request->created_at); ?>

                </td>
                <td>
                    <?php echo e($request->request_status); ?>

                </td>
                <td>
                    <?php if($request->request_status == 'pending'): ?>
                    <div class="row">

                        <div class='col-6'>
                            <form action='<?php echo e(route('admin.request.verify', $request)); ?>' method='post'>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <button type="submit" class="btn btn-primary btn-block">Verified</button>
                            </form>
                        </div>

                        <div class='col-6'>
                            <form action='<?php echo e(route('admin.request.deny', $request)); ?>' method='post'>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <button type="submit" class="btn btn-danger btn-block">Deny</button>
                            </form>
                        </div>

                    </div>
                    <?php else: ?>

                    <a name="" id="" class="btn btn-outline-info btn-block" role="button" disabled><?php echo e($request->request_status); ?></a>

                    <?php endif; ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class='text-center'>
            <tr>
                <th>ID</th>
                <th>Type</th>
                <th>User</th>
                <th>Description</th>
                <th>Data</th>
                <th>Created at</th>
                <th>Status</th>
                <th>&nbsp;</th>
            </tr>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quizy\resources\views/admin/request/index.blade.php ENDPATH**/ ?>