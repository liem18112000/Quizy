<?php $__env->startSection('styles'); ?>
    <script src="https://cdn.tiny.cloud/1/rmdclr9q9pr72tgrpg0w7x3r0kqnglgojdaxfqsij86e4bp0/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
    <style>
        .float-panel{
            position: fixed;
            width: 20%;
            top: 2vh;
            left: 5%;
        }

        .border-red{
            border: 3px solid red!important;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="container-fluid" style='margin-top:2vh; margin-bottom:5vh'>
        <div class="row">
            <div class="col-lg-3">
                <div class='float-panel'>
                    <div class="row">
                        <div class='col-lg-12'>
                            <div class="card mb-2">
                                <div class="card-body">
                                    <h4 class="card-title text-center">Thoi gian còn lại</h4>

                                    <!-- Display the countdown timer in an element -->
                                    <h2 id="demo" class='text-center'></h2>

                                    <script>

                                        // Set the date we're counting down to
                                        var countDownDate = new Date(new Date().getTime() + <?php echo e($doing->remain_time); ?> * 1000).getTime();

                                        // Update the count down every 1 second
                                        var x = setInterval(function() {

                                        // Get today's date and time
                                        var now = new Date().getTime();

                                        // Find the distance between now and the count down date
                                        var distance = countDownDate - now;
                                        window.value = distance / 1000;

                                        // Time calculations for days, hours, minutes and seconds
                                        var minutes = Math.floor(distance / (1000 * 60));
                                        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                                        // Display the result in the element with id="demo"
                                        document.getElementById("demo").innerHTML = minutes + " : " + seconds;

                                        // If the count down is finished, write some text
                                        if (distance < 0) {
                                            clearInterval(x);
                                            document.getElementById("demo").innerHTML = "EXPIRED";
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Hết thời gian',
                                                text: 'Hoàn thành bài làm!'
                                            });
                                            document.getElementById('question-form').submit();
                                        }
                                        }, 1000);
                                    </script>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">

                                    <h4 class="card-title text-center">Câu hỏi</h4>

                                    <?php for($j = 0 ; $j < $questions->count() / 5 ; $j++): ?>
                                    <div class='mt-2' style='display:flex; justify-content: space-evenly;'>
                                        <?php for($k = 0; $k < 5; $k++): ?>
                                            <?php if($j * 5 + $k + 1 <= count($questions)): ?>
                                                <a name="" id="btn<?php echo e($j * 5 + $k + 1); ?>" class="btn

                                                <?php if(isset($answer['check' . ($j * 5 + $k + 1)])): ?>
                                                    border-red
                                                <?php endif; ?>

                                                <?php if(isset($answer['choice' . ($j * 5 + $k + 1)])): ?>
                                                    btn-success
                                                <?php else: ?>
                                                    btn-outline-dark
                                                <?php endif; ?>

                                                " style='width: 48px' href="#<?php echo e($j * 5 + $k + 1); ?>" role="button">
                                                    <?php echo e($j * 5 + $k + 1); ?>

                                                </a>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </div>
                                    <?php endfor; ?>

                                    <a class="btn btn-primary mt-4 btn-block"
                                    onclick="event.preventDefault();
                                    document.getElementById('time_remain').value = window.value;
                                    document.getElementById('question-form').submit();" href='#'>Nộp Bài</a>

                                    <a class="btn btn-secondary btn-block"
                                    onclick="event.preventDefault();
                                    document.getElementById('time_remain').value = window.value;
                                    document.getElementById('isPause').value = 'true';
                                    document.getElementById('question-form').submit();" href='#'>Tạm ngưng</a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-9">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card text-center" >
                            <div class="card-body">
                                <h1 class="card-title">Đề thi : <?php echo e($course->name); ?> - <?php echo e($exam->title); ?></h1>
                                <h5 class="card-text">Tên thí sinh: <?php echo e(Auth::user()->name); ?></h5>
                            </div>
                        </div>
                    </div>
                </div>


                <?php
                    $cau = 1;
                ?>

                <form action='<?php echo e(route('exam.submit', [$course, $exam, $doing])); ?>' method='POST' id='question-form'>
                <?php echo csrf_field(); ?>
                    <input type='hidden' name='isPause' id='isPause' value='false'>
                    <input type='hidden' name='time_remain' id='time_remain'>
                    <input type='hidden' name='exam_type_id' value='<?php echo e($exam->exam_type_id); ?>'>

                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Cau hoi -->
                        <div class="row mt-2">
                            <div class="col-lg-12">
                                <div class="card" >
                                    <div class="card-body" id='<?php echo e($cau); ?>'>

                                        <div style='display:flex; justify-content: space-between;'>
                                            <h4 class="card-title">Câu hỏi <?php echo e($cau); ?></h4>
                                            <div class="form-check">
                                                <label class="form-check-label">
                                                <script>
                                                    function onCheck(id)
                                                    {
                                                        document.getElementById(id).classList.add('border-red');
                                                    }

                                                    function onUnCheck(id)
                                                    {
                                                        document.getElementById(id).classList.remove('border-red');
                                                    }
                                                </script>
                                                <input type="checkbox" class="form-check-input" name="check<?php echo e($cau); ?>" id="check<?php echo e($cau); ?>" value="true"
                                                onclick="if (this.checked) { onCheck('btn<?php echo e($cau); ?>') } else { onUnCheck('btn<?php echo e($cau); ?>') }"
                                                <?php if(isset($answer['check' . $cau])): ?>
                                                    checked
                                                <?php endif; ?>
                                                >
                                                Đánh dấu
                                            </label>
                                            </div>
                                        </div>

                                        <p class="card-text"><?php echo e($question->description); ?>?</p>

                                        <?php if($exam->examType->id == '1'): ?>

                                            
                                            <?php
                                                $i = 1;
                                            ?>

                                            <?php $__currentLoopData = $question->choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <!-- Group of default radios - option 1 -->
                                                <div class="custom-control custom-radio">
                                                    <input value='<?php echo e($i); ?>' type="radio" class="custom-control-input" id="<?php echo e($cau); ?>-choice-<?php echo e($i); ?>" name="choice<?php echo e($cau); ?>"
                                                    onclick="document.getElementById('btn<?php echo e($cau); ?>').classList.add('btn-success');
                                                    document.getElementById('btn<?php echo e($cau); ?>').classList.remove('btn-outline-dark')"
                                                    <?php if(isset($answer['choice' . $cau]) && $answer['choice' . $cau] == $i): ?>
                                                        checked
                                                    <?php endif; ?>>

                                                    <label class="custom-control-label" for="<?php echo e($cau); ?>-choice-<?php echo e($i); ?>"><?php echo e($choice->description); ?></label>
                                                </div>

                                                <?php
                                                    $i++;
                                                ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            

                                        <?php elseif($exam->examType->id == '2'): ?>

                                            
                                            <hr/>
                                            <textarea id="<?php echo e($cau); ?>-choice" rows='20' name="choice<?php echo e($cau); ?>">
                                                <?php if(isset($answer['choice' . $cau])): ?>
                                                    <?php echo $answer['choice' . $cau]; ?>

                                                <?php endif; ?>
                                            </textarea>
                                            <script>
                                                tinymce.init({
                                                    selector: 'textarea#<?php echo e($cau); ?>-choice',
                                                    plugins: 'advlist autolink lists link image charmap print preview hr anchor pagebreak',
                                                    toolbar_mode: 'floating',
                                                    init_instance_callback: function(editor) {
                                                        editor.on('input', function(e) {
                                                            document.getElementById('btn<?php echo e($cau); ?>').classList.add('btn-success');
                                                            document.getElementById('btn<?php echo e($cau); ?>').classList.remove('btn-outline-dark')
                                                        });
                                                    }
                                                });
                                            </script>
                                            

                                        <?php endif; ?>

                                        <?php
                                            $cau++;
                                        ?>


                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Cau hoi -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                    </form>
                </form>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appNoNavNoFoot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quizy\resources\views/exam/show.blade.php ENDPATH**/ ?>