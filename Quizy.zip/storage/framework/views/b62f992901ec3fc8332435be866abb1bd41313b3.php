<?php $__env->startSection('content'); ?>
    <h1 style='padding-left: 40px;'>Course Enrollment</h1>

    <hr/>

    <table id="example" class="table table-hover table-striped table-bordered" style="width:100%">
        <thead class='text-center'>
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Creator</th>
                <th>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='text-center'>
                <td style='padding-top: 15px;'><?php echo e($course->id); ?></td>
                <td style='padding: 0; width: 60px;'>
                    <?php if($course->image == 'untitled'): ?>
                        <img
                            src="https://wallpaperplay.com/walls/full/1/3/2/296805.jpg" alt=""
                            class='img-responsive img-rounded'
                            style='height: 100px; width: 100px; object-fit: cover'>
                    <?php else: ?>
                        <img
                            src="<?php echo e($course->image); ?>" alt=""
                            class='img-responsive img-rounded'
                            style='height: 100px; width: 100px; object-fit: cover'>
                    <?php endif; ?>
                </td>
                <td style='padding-top: 15px;'><?php echo e($course->name); ?></td>
                <td style='padding-top: 15px;'><a href="#"><?php echo e(Auth::user()->name); ?></a></td>
                <td class='text-center' style='padding-top: 10px;'>

                    <?php if($course->hasStudent->first() && $course->hasStudent->first()->enrollBy->user->find(Auth::user()->id)): ?>
                        <a class="btn btn-info btn-block" href="<?php echo e(route('student.course.exam', $course)); ?>" role="button"> View Exams</a>
                    <?php else: ?>
                        <form action='<?php echo e(route('course.enroll', $course)); ?>' method='POST'>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary btn-block">Enroll Course</button>
                        </form>
                    <?php endif; ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class='text-center'>
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Creator</th>
                <th>&nbsp;</th>
            </tr>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quizy\resources\views/student/course.blade.php ENDPATH**/ ?>