<?php $__env->startSection('content'); ?>
    <h1 style='padding-left: 40px;'>Result Board</h1>

    <hr/>

    <table id="example" class="table table-hover table-striped table-bordered" style="width:100%">
        <thead class='text-center'>
            <tr>
                <th>ID</th>
                <th>Course</th>
                <th>Exam</th>
                <th>Time eslasped</th>
                <th>Right answers</th>
                <th>Grade</th>
                <th>Time taken</th>
                <th>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='text-center'>
                <td><?php echo e($result->id); ?></td>
                <td>
                    <?php echo e($result->course->name); ?>

                </td>
                <td><?php echo e($result->exam->title); ?></td>
                <td><?php echo e(floor($result->remain_time / 60)); ?> minutes <?php echo e($result->remain_time % 60); ?> seconds / <?php echo e($result->exam->duration_min); ?> minutes</td>
                <td><?php echo e($result->grade); ?> / <?php echo e(count($result->exam->questions)); ?></td>
                <td>
                    <?php echo e(100 * $result->grade / count($result->exam->questions)); ?> points
                </td>
                <td><?php echo e($result->created_at); ?></td>
                <td>
                    <a class="btn btn-outline-primary" href="<?php echo e(route('student.course.exam.preview', [$result->course, $result->exam])); ?>" role="button">Preview Results</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class='text-center'>
            <tr>
                <th>ID</th>
                <th>Course</th>
                <th>Exam</th>
                <th>Time eslasped</th>
                <th>Right answers</th>
                <th>Grade</th>
                <th>Time taken</th>
                <th>&nbsp;</th>
            </tr>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quizy\resources\views/student/result.blade.php ENDPATH**/ ?>