<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <?php echo $__env->yieldContent('styles'); ?>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link rel="icon" href="<?php echo e(asset('img/favicon.png')); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <!-- animate CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
    <!-- owl carousel CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
    <!-- themify CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/themify-icons.css')); ?>">
    <!-- flaticon CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/flaticon.css')); ?>">
    <!-- font awesome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
    <!-- swiper CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/slick.css')); ?>">
    <!-- style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>

    <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">



</head>
<body>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- jquery plugins here-->
    <!-- jquery -->
    <script src="<?php echo e(asset('js/jquery-1.12.1.min.js')); ?>"></script>
    <!-- popper js -->
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <!-- bootstrap js -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <!-- easing js -->
    <script src="<?php echo e(asset('js/jquery.magnific-popup.js')); ?>"></script>
    <!-- swiper js -->
    <script src="<?php echo e(asset('js/swiper.min.js')); ?>"></script>
    <!-- swiper js -->
    <script src="<?php echo e(asset('js/masonry.pkgd.js')); ?>"></script>
    <!-- particles js -->
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.nice-select.min.js')); ?>"></script>
    <!-- swiper js -->
    <script src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/waypoints.min.js')); ?>"></script>
    <!-- custom js -->
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\Quizy\resources\views\layouts\appNoNavNoFoot.blade.php ENDPATH**/ ?>