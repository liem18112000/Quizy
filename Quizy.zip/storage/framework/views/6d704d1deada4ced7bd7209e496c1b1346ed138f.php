<?php $__env->startSection('content'); ?>


<!--::review_part start::-->
<section class="special_cource padding_top">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-5">
                <div class="section_tittle text-center">
                    <h2>Dashboard</h2>
                </div>
            </div>
        </div>
        <div class="row">
        <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-lg-4 mb-4">
                <div class="card">
                    <img src="
                        <?php if($role->roleType->name == 'admin'): ?>
                            <?php echo e(asset('img/admin.png')); ?>

                        <?php elseif($role->roleType->name == 'lecturer'): ?>
                            <?php echo e(asset('img/lecturer.png')); ?>

                        <?php else: ?>
                            <?php echo e(asset('img/student.png')); ?>

                        <?php endif; ?>
                    " class="special_img" style='object-fit:cover;' alt="">
                    <div class="card-footer">
                        <a
                        <?php if($role->roleType->name == 'admin'): ?>
                            href="<?php echo e(route('admin.dashboard')); ?>"
                        <?php elseif($role->roleType->name == 'lecturer'): ?>
                            href="<?php echo e(route('lecturer.dashboard')); ?>"
                        <?php else: ?>
                            href="<?php echo e(route('student.dashboard')); ?>"
                        <?php endif; ?>
                            class="btn btn-outline-dark btn-block"> <?php echo e($role->roleType->name); ?> Dashboard</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!--::blog_part end::-->

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quizy\resources\views/main-dashboard.blade.php ENDPATH**/ ?>