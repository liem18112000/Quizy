<?php $__env->startSection('content'); ?>
    <h1 style='padding-left: 40px;'>Course : <?php echo e($course->name); ?></h1>

    <h2 style='padding-left: 40px;'>Exam Management</h2>

    <hr/>
    <!-- Button trigger modal -->
    <div style='padding-left: 40px;'>
        <a name="" id="" class="btn btn-secondary" href="<?php echo e(route('admin.course')); ?>" role="button">Back</a>
    </div>

    <hr/>

    <table id="example" class="table table-hover table-striped table-bordered" style="width:100%">
        <thead class='text-center'>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Creator</th>
                <th>Allow time</th>
                <th>Duration</th>
                <th>Question</th>
                <th>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='text-center'>
                <td><?php echo e($exam->id); ?></td>
                <td>
                    <?php echo e($exam->title); ?>

                </td>
                <td></td>
                <td><?php echo e($exam->allow_time); ?></td>
                <td><?php echo e($exam->duration_min); ?></td>
                <td>
                    <a name="" id="" class="btn btn-primary" href="<?php echo e(route('admin.course.exam.question', [$course, $exam])); ?>" role="button">
                        Question Count : <?php echo e($exam->questions->count()); ?>

                    </a>
                </td>
                <td class='text-center' style='padding-top: 10px;'>
                    <a name="" id="" class="mx-1 btn btn-danger" href="#" role="button">Disable</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class='text-center'>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Creator</th>
                <th>Allow time</th>
                <th>Duration</th>
                <th>Question</th>
                <th>&nbsp;</th>
            </tr>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Quizy\resources\views/admin/exam.blade.php ENDPATH**/ ?>